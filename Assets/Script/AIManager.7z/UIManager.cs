using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using DG.Tweening;

public class UIManager : MonoBehaviour
{
    public Transform playerHandPanel;
    public Transform opponentHandPanel;
    public Transform playerFieldPanel;
    public Transform opponentFieldPanel;
    public Text playerHealthText;
    public Text opponentHealthText;
    public Text playerManaText;
    public Text gameOverText;
    public GameObject cardPrefab;
    public float cardSpacing = 10f;
    private List<GameObject> playerCardUIs = new List<GameObject>();
    private List<GameObject> opponentCardUIs = new List<GameObject>();
    private List<GameObject> playerFieldCardUIs = new List<GameObject>();
    private List<GameObject> opponentFieldCardUIs = new List<GameObject>();

    void Awake()
    {
        if (playerHandPanel == null || opponentHandPanel == null || 
            playerFieldPanel == null || opponentFieldPanel == null || cardPrefab == null)
        {
            Debug.LogError("UIManager: One or more UI components are not assigned!");
        }

        EnsureLayoutGroup(playerHandPanel);
        EnsureLayoutGroup(opponentHandPanel);
        EnsureLayoutGroup(playerFieldPanel);
        EnsureLayoutGroup(opponentFieldPanel);
    }

    void EnsureLayoutGroup(Transform panel)
    {
        if (panel == null) return;
        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout == null)
        {
            layout = panel.gameObject.AddComponent<HorizontalLayoutGroup>();
        }
        layout.padding = new RectOffset(10, 10, 10, 10);
        layout.spacing = cardSpacing;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childForceExpandWidth = false;
        layout.childForceExpandHeight = false;
    }

    public void UpdateUI()
    {
        if (playerHealthText != null)
            playerHealthText.text = "玩家生命: " + GameManager.Instance.playerHealth;
        if (opponentHealthText != null)
            opponentHealthText.text = "對手生命: " + GameManager.Instance.opponentHealth;
        if (playerManaText != null)
            playerManaText.text = "魔力: " + GameManager.Instance.playerMana + "/" + GameManager.Instance.maxMana;

        UpdateHand(GameManager.Instance.playerHand, playerHandPanel, true);
        UpdateHand(GameManager.Instance.opponentHand, opponentHandPanel, false);
        UpdateField(GameManager.Instance.playerField, playerFieldPanel, true);
        UpdateField(GameManager.Instance.opponentField, opponentFieldPanel, false);
    }

    void UpdateHand(List<Card> hand, Transform panel, bool isPlayer)
    {
        if (panel == null)
        {
            Debug.LogError("UIManager: Panel is null for UpdateHand!");
            return;
        }

        List<GameObject> cardUIs = isPlayer ? playerCardUIs : opponentCardUIs;
        foreach (var cardUI in cardUIs)
        {
            if (cardUI != null)
            {
                DG.Tweening.DOTween.Kill(cardUI.transform);
                Destroy(cardUI);
            }
        }
        cardUIs.Clear();

        foreach (var card in hand)
        {
            if (card == null) continue;

            GameObject cardObj = Instantiate(cardPrefab, panel);
            CardUI cardUI = cardObj.GetComponent<CardUI>();
            if (cardUI != null)
            {
                cardUI.Initialize(card, isPlayer, false);
                cardUIs.Add(cardObj);

                RectTransform rect = cardObj.GetComponent<RectTransform>();
                rect.localScale = Vector3.one;
                rect.sizeDelta = new Vector2(100, 150);
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.localPosition = Vector3.zero;
                Debug.Log($"Card {card.name} added to {(isPlayer ? "playerHandPanel" : "opponentHandPanel")} with Anchor: {rect.anchorMin}, Pivot: {rect.pivot}.");
            }
            else
            {
                Debug.LogError("UIManager: CardUI component missing on card prefab!");
                Destroy(cardObj);
            }
        }

        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout != null)
        {
            layout.spacing = cardSpacing;
        }
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(panel.GetComponent<RectTransform>());
    }

    void UpdateField(List<Card> field, Transform panel, bool isPlayer)
    {
        if (panel == null)
        {
            Debug.LogError($"UIManager: {(isPlayer ? "playerFieldPanel" : "opponentFieldPanel")} is null for UpdateField!");
            return;
        }

        List<GameObject> fieldCardUIs = isPlayer ? playerFieldCardUIs : opponentFieldCardUIs;
        foreach (var cardUI in fieldCardUIs)
        {
            if (cardUI != null)
            {
                DG.Tweening.DOTween.Kill(cardUI.transform);
                Destroy(cardUI);
            }
        }
        fieldCardUIs.Clear();

        foreach (var card in field)
        {
            if (card == null) continue;

            GameObject cardObj = Instantiate(cardPrefab, panel);
            CardUI cardUI = cardObj.GetComponent<CardUI>();
            if (cardUI != null)
            {
                cardUI.Initialize(card, isPlayer, true);
                fieldCardUIs.Add(cardObj);

                RectTransform rect = cardObj.GetComponent<RectTransform>();
                rect.localScale = Vector3.one;
                rect.sizeDelta = new Vector2(100, 150);
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.localPosition = Vector3.zero;
                Debug.Log($"Card {card.name} added to {(isPlayer ? "playerFieldPanel" : "opponentFieldPanel")} with Anchor: {rect.anchorMin}, Pivot: {rect.pivot}.");
            }
            else
            {
                Debug.LogError("UIManager: CardUI component missing on card prefab!");
                Destroy(cardObj);
            }
        }

        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout != null)
        {
            layout.spacing = cardSpacing;
        }
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(panel.GetComponent<RectTransform>());
    }

    public void PlayCardWithAnimation(Card card, bool isPlayer, GameObject cardObject, Transform sourcePanel, Transform targetPanel)
    {
        if (card == null || cardObject == null || sourcePanel == null || targetPanel == null)
        {
            Debug.LogError("PlayCardWithAnimation: Invalid parameters!");
            return;
        }

        // 殺死所有與此對象相關的 DOTween 動畫
        DOTween.Kill(cardObject.transform);
        Image cardImage = cardObject.GetComponent<Image>();
        if (cardImage != null)
        {
            DOTween.Kill(cardImage);
        }

        RectTransform cardRect = cardObject.GetComponent<RectTransform>();
        if (cardRect == null)
        {
            Debug.LogError("PlayCardWithAnimation: Card object missing RectTransform!");
            return;
        }

        // 強制更新 Canvas
        Canvas.ForceUpdateCanvases();

        // 禁用源面板佈局
        HorizontalLayoutGroup sourceLayout = sourcePanel.GetComponent<HorizontalLayoutGroup>();
        bool wasSourceLayoutEnabled = sourceLayout != null && sourceLayout.enabled;
        if (sourceLayout != null) sourceLayout.enabled = false;

        // 記錄起始位置
        Vector3 startPos = cardRect.position;

        // 禁用目標面板佈局
        HorizontalLayoutGroup targetLayout = targetPanel.GetComponent<HorizontalLayoutGroup>();
        bool wasTargetLayoutEnabled = targetLayout != null && targetLayout.enabled;
        if (targetLayout != null) targetLayout.enabled = false;

        // 計算目標位置
        RectTransform targetRect = targetPanel.GetComponent<RectTransform>();
        Vector3 targetPos = targetRect.position;

        // 重新設置父對象到 Canvas 以實現平滑動畫
        cardObject.transform.SetParent(targetPanel.root, true);
        cardRect.position = startPos;

        // 如果是對手卡牌，確保顯示卡背
        if (!isPlayer && cardImage != null)
        {
            CardUI cardUI = cardObject.GetComponent<CardUI>();
            if (cardUI != null && cardUI.cardBackSprite != null)
            {
                cardImage.sprite = cardUI.cardBackSprite;
            }
            else
            {
                cardImage.sprite = null;
                cardImage.color = Color.gray;
            }
            
            // 隱藏文字
            Text[] texts = cardObject.GetComponentsInChildren<Text>();
            foreach (Text text in texts)
            {
                text.text = "";
            }
        }

        // 播放動畫
        Sequence seq = DOTween.Sequence();
        
        // 第一步：放大效果
        seq.Append(cardRect.DOScale(Vector3.one * 1.2f, 0.2f));
        
        // 第二步：移動到場上
        seq.Append(cardRect.DOMove(targetPos, 0.5f).SetEase(Ease.OutQuad));
        
        // 對手卡牌特殊動畫
        if (!isPlayer)
        {
            // 第三步：翻轉動畫 (90度)
            seq.Append(cardRect.DORotate(new Vector3(0, 90, 0), 0.2f));
            
            // 翻轉中途切換為正面
            seq.AppendCallback(() => {
                if (cardImage != null)
                {
                    cardImage.sprite = card.sprite;
                    // 顯示卡牌信息
                    CardUI cardUI = cardObject.GetComponent<CardUI>();
                    if (cardUI != null)
                    {
                        if (cardUI.nameText != null) cardUI.nameText.text = card.name;
                        if (cardUI.descriptionText != null) cardUI.descriptionText.text = card.effect;
                        if (cardUI.costText != null) cardUI.costText.text = card.cost.ToString();
                        if (cardUI.attackText != null) cardUI.attackText.text = card.attack.ToString();
                        if (cardUI.valueText != null) cardUI.valueText.text = card.value.ToString();
                    }
                }
            });
            
            // 第四步：完成翻轉 (0度)
            seq.Append(cardRect.DORotate(Vector3.zero, 0.2f));
            
            // 第五步：停留顯示 (可調整時間)
            seq.AppendInterval(1.0f); // 停留1秒
            
            // 第六步：淡出消失
            if (cardImage != null)
            {
                seq.Append(cardImage.DOFade(0, 0.5f));
            }
        }
        else
        {
            // 玩家卡牌簡單縮放
            seq.Append(cardRect.DOScale(Vector3.one, 0.2f));
        }
        
        // 動畫完成後的回調
        seq.OnComplete(() => {
            // 恢復佈局
            if (sourceLayout != null && wasSourceLayoutEnabled)
                sourceLayout.enabled = true;
            if (targetLayout != null && wasTargetLayoutEnabled)
                targetLayout.enabled = true;

            // 應用卡牌效果
            card.ApplyCardEffect(isPlayer);
            GameManager.Instance.CheckGameOver();

            // 安全銷毀卡牌對象
            if (cardObject != null)
            {
                Destroy(cardObject);
            }
            
            CardUI.IsAnimationPlaying = false;
            // 在動畫完成後才更新UI
            GameManager.Instance.UIManager.UpdateUI();
        });
        
        seq.OnKill(() => {
            CardUI.IsAnimationPlaying = false;
        });
    }

    public void ShowGameOver(string message)
    {
        if (gameOverText != null)
        {
            gameOverText.text = message;
            gameOverText.gameObject.SetActive(true);
        }
    }
}