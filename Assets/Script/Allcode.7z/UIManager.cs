using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using DG.Tweening ;
using UVS = Unity.VisualScripting;

public class UIManager : MonoBehaviour
{
    public Transform playerHandPanel;
    public Transform opponentHandPanel;
    public Transform playerFieldPanel;
    public Transform opponentFieldPanel;
    public Text playerHealthText;
    public Text opponentHealthText;
    public Text playerManaText;
    public Text gameOverText;
    public GameObject cardPrefab;
    public float cardSpacing = 10f;
    private List<GameObject> playerCardUIs = new List<GameObject>();
    private List<GameObject> opponentCardUIs = new List<GameObject>();
    private List<GameObject> playerFieldCardUIs = new List<GameObject>();
    private List<GameObject> opponentFieldCardUIs = new List<GameObject>();

    void Awake()
    {
        if (playerHandPanel == null || opponentHandPanel == null || 
            playerFieldPanel == null || opponentFieldPanel == null || cardPrefab == null)
        {
            Debug.LogError("UIManager: One or more UI components are not assigned!");
        }

        EnsureLayoutGroup(playerHandPanel);
        EnsureLayoutGroup(opponentHandPanel);
        EnsureLayoutGroup(playerFieldPanel);
        EnsureLayoutGroup(opponentFieldPanel);
    }

    void EnsureLayoutGroup(Transform panel)
    {
        if (panel == null) return;
        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout == null)
        {
            layout = panel.gameObject.AddComponent<HorizontalLayoutGroup>();
        }
        layout.padding = new RectOffset(10, 10, 10, 10);
        layout.spacing = cardSpacing;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childForceExpandWidth = false;
        layout.childForceExpandHeight = false;
    }

    public void UpdateUI()
    {
        if (playerHealthText != null)
            playerHealthText.text = "玩家生命: " + GameManager.Instance.playerHealth;
        if (opponentHealthText != null)
            opponentHealthText.text = "對手生命: " + GameManager.Instance.opponentHealth;
        if (playerManaText != null)
            playerManaText.text = "魔力: " + GameManager.Instance.playerMana + "/" + GameManager.Instance.maxMana;

        UpdateHand(GameManager.Instance.playerHand, playerHandPanel, true);
        UpdateHand(GameManager.Instance.opponentHand, opponentHandPanel, false);
        UpdateField(GameManager.Instance.playerField, playerFieldPanel, true);
        UpdateField(GameManager.Instance.opponentField, opponentFieldPanel, false);
    }

    void UpdateHand(List<Card> hand, Transform panel, bool isPlayer)
    {
        if (panel == null)
        {
            Debug.LogError("UIManager: Panel is null for UpdateHand!");
            return;
        }

        List<GameObject> cardUIs = isPlayer ? playerCardUIs : opponentCardUIs;
        foreach (var cardUI in cardUIs)
        {
            if (cardUI != null)
            {
                DG.Tweening.DOTween.Kill(cardUI.transform);
                Destroy(cardUI);
            }
        }
        cardUIs.Clear();

        foreach (var card in hand)
        {
            if (card == null) continue;

            GameObject cardObj = Instantiate(cardPrefab, panel);
            CardUI cardUI = cardObj.GetComponent<CardUI>();
            if (cardUI != null)
            {
                cardUI.Initialize(card, isPlayer, false);
                cardUIs.Add(cardObj);

                RectTransform rect = cardObj.GetComponent<RectTransform>();
                rect.localScale = Vector3.one;
                rect.sizeDelta = new Vector2(100, 150);
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.localPosition = Vector3.zero;
                //Debug.Log($"Card {card.name} added to {(isPlayer ? "playerHandPanel" : "opponentHandPanel")} with Anchor: {rect.anchorMin}, Pivot: {rect.pivot}.");
            }
            else
            {
                Debug.LogError("UIManager: CardUI component missing on card prefab!");
                Destroy(cardObj);
            }
        }

        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout != null)
        {
            layout.spacing = cardSpacing;
        }
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(panel.GetComponent<RectTransform>());
    }

    void UpdateField(List<Card> field, Transform panel, bool isPlayer)
    {
        if (panel == null)
        {
            Debug.LogError($"UIManager: {(isPlayer ? "playerFieldPanel" : "opponentFieldPanel")} is null for UpdateField!");
            return;
        }

        List<GameObject> fieldCardUIs = isPlayer ? playerFieldCardUIs : opponentFieldCardUIs;
        foreach (var cardUI in fieldCardUIs)
        {
            if (cardUI != null)
            {
                DG.Tweening.DOTween.Kill(cardUI.transform);
                Destroy(cardUI);
            }
        }
        fieldCardUIs.Clear();

        foreach (var card in field)
        {
            if (card == null) continue;

            GameObject cardObj = Instantiate(cardPrefab, panel);
            CardUI cardUI = cardObj.GetComponent<CardUI>();
            if (cardUI != null)
            {
                cardUI.Initialize(card, isPlayer, true);
                fieldCardUIs.Add(cardObj);

                RectTransform rect = cardObj.GetComponent<RectTransform>();
                rect.localScale = Vector3.one;
                rect.sizeDelta = new Vector2(100, 150);
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.localPosition = Vector3.zero;
                Debug.Log($"Card {card.name} added to {(isPlayer ? "playerFieldPanel" : "opponentFieldPanel")} with Anchor: {rect.anchorMin}, Pivot: {rect.pivot}.");
            }
            else
            {
                Debug.LogError("UIManager: CardUI component missing on card prefab!");
                Destroy(cardObj);
            }
        }

        HorizontalLayoutGroup layout = panel.GetComponent<HorizontalLayoutGroup>();
        if (layout != null)
        {
            layout.spacing = cardSpacing;
        }
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(panel.GetComponent<RectTransform>());
    }

    public void PlayCardWithAnimation(Card card, bool isPlayer, GameObject cardObject, Transform sourcePanel, Transform targetPanel)
    {
        // 增加参数检查
        if (card == null || cardObject == null || sourcePanel == null || targetPanel == null)
        {
            Debug.LogError("动画参数错误！");
            return;
        }

        // 立即终止该对象上所有现有动画
        DOTween.Kill(cardObject.transform, true); // true表示完全终止
        
        // 添加销毁标记
        bool wasDestroyed = false;
        
        // 获取组件引用
        RectTransform cardRect = cardObject.GetComponent<RectTransform>();
        CardUI cardUI = cardObject.GetComponent<CardUI>();
        Image cardImage = cardObject.GetComponent<Image>();
        if (cardImage == null)
        {
            cardObject.AddComponent<Image>();
            cardImage = cardObject.GetComponent<Image>();
        }
 

        // 创建动画序列
        Sequence seq = DOTween.Sequence();
        // 第一步：放大效果
        seq.Append(cardRect.DOScale(1.2f, 0.2f)
        .OnUpdate(() =>
        {
            if (cardObject == null) wasDestroyed = true;
            Debug.LogWarning("❗ 卡片在 DOScale 動畫期間被 Destroy");
        }));
        // 第二步：移动到场上
        seq.Append(cardRect.DOMove(targetPanel.position, 0.5f)
        .SetEase(Ease.OutQuad)
        .OnUpdate(() =>
        {
            if (cardObject == null) wasDestroyed = true;
            Debug.LogWarning("❗ 卡片在 DOMove 動畫期間被 Destroy");
        }));

        // 对手卡牌特殊处理
        if (!isPlayer)
        {
            // 第三步：翻牌动画
            seq.Append(cardRect.DORotate(new Vector3(0, 90, 0), 0.2f)
            .OnUpdate(() =>
            {
                if (cardObject == null) wasDestroyed = true;
                Debug.LogWarning("❗ 卡片在 DORotate 動畫期間被 Destroy");
            })
            .OnComplete(() =>
            {
                if (!wasDestroyed && cardObject != null)
                {
                    // 翻牌后显示卡面
                    if (cardImage == null)
                    {
                        Debug.LogError("CardUI: cardImage is null!");
                        return;
                    }
                    cardImage.sprite = card.sprite;
                    // 更新卡牌文字信息...
                }
            }));


            // 第四步：完成翻转
            seq.Append(cardRect.DORotate(Vector3.zero, 0.2f));

            // 第五步：淡出效果
            seq.Append(cardImage.DOFade(0, 0.5f));
            if(cardRect == null || cardImage == null)
            {
                Debug.LogError("CardUI: "+(cardRect == null ? "cardRect" : "") +
                (cardImage == null ? "and cardImage" : "") +
                $" is null!");
                return;
            }
        }

        // 动画完成回调
        seq.OnComplete(() =>
        {
            if (!wasDestroyed && cardObject != null)
            {
                card.ApplyCardEffect(isPlayer);
                Destroy(cardObject);
            }

            CardUI.IsAnimationPlaying = false;
            StartCoroutine(DelayedUpdateUI());

            StartCoroutine(DestroyAfterFrame(cardObject));
        });
        
        // 动画被强制终止的回调
        seq.OnKill(() => {
            CardUI.IsAnimationPlaying = false;
            StartCoroutine(DelayedUpdateUI());
        });
    }

    private IEnumerator<WaitForSeconds> DelayedUpdateUI()
    {
        yield return new WaitForSeconds(0.2f); // 足夠的延遲確保動畫完全結束
        GameManager.Instance.UIManager.UpdateUI();
    }
    IEnumerator<UVS.Null> DestroyAfterFrame(GameObject obj)
    {
        yield return null; // 等一幀
        if (obj != null)
            Destroy(obj);
    }
    public void ShowGameOver(string message)
    {
        if (gameOverText != null)
        {
            gameOverText.text = message;
            gameOverText.gameObject.SetActive(true);
        }
    }
}